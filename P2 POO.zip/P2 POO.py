from abc import ABC, abstractmethod
import pandas as pd

class Aluno:
    def __init__(self, nome, idade, status='ativo'):
        self.nome = nome
        self.idade = idade
        self.status = status

    def cadastrar_aluno_df(self):
        data = {'Nome': [self.nome], 'Idade': [self.idade], 'Status': [self.status]}
        df = pd.DataFrame(data)
        return df

class AcaoAluno(ABC):
    @abstractmethod
    def advertir(self, aluno, motivo):
        pass

    @abstractmethod
    def expulsar(self, aluno):
        pass

class Administrador(AcaoAluno):
    def __init__(self, senha):
        self.senha = senha

    def validar_senha(self, senha):
        return self.senha == senha
    
    def advertir(self, aluno, motivo):
        aluno.status = 'advertência'
        aluno.motivo_advertencia = motivo

    def expulsar(self, aluno):
        aluno.status = 'expulso'

class CadastroAlunos:
    def __init__(self):
        self.dados_alunos = pd.DataFrame(columns=['Nome', 'Idade', 'Status'])

    def cadastrar_aluno(self, aluno):
        novo_aluno = pd.DataFrame([[aluno.nome, aluno.idade, aluno.status]], columns=['Nome', 'Idade', 'Status'])
        self.dados_alunos = pd.concat([self.dados_alunos, novo_aluno], ignore_index=True)

    def advertir_aluno(self, nome_aluno):
        index_aluno = self.dados_alunos[self.dados_alunos['Nome'] == nome_aluno].index
        if not index_aluno.empty:
            self.dados_alunos.at[index_aluno[0], 'Status'] = 'advertência'
            print(f"Aluno {nome_aluno} levou uma advertência.")
        else:
            print("Aluno não encontrado na instituição.")

    def expulsar_aluno(self, nome_aluno):
        index_aluno = self.dados_alunos[self.dados_alunos['Nome'] == nome_aluno].index
        if not index_aluno.empty:
            self.dados_alunos.at[index_aluno[0], 'Status'] = 'expulso'
            print(f"Aluno {nome_aluno} foi expulso da instituição.")
        else:
            print("Aluno não foi localizado.")

class AcoesAluno:
    def __init__(self):
        self.cadastro_alunos = CadastroAlunos()
        self.administrador = Administrador('0000')

    def painel_alunos(self):
        print("Painel de relação de Alunos:")
        print(self.cadastro_alunos.dados_alunos)

    def realizar_acao(self):
        print("\nMenu de interação da instituição")
        print("1. Mostrar todos os alunos")
        print("2. Adicionar novo aluno há instituição")
        print("3. Advertir aluno da instituição")
        print("4. Expulsar aluno da instituição")
        print("5. Sair do programa")

        escolha = input("Digite o número do menu desejado: ")
        if escolha == '1':
            self.painel_alunos()
        elif escolha == '2':
            senha = input("Digite a senha de administrador para adicionar aluno novo aluno há instituição: ")
            if self.administrador.validar_senha(senha):
                nome = input("Digite o nome do aluno: ")
                idade = int(input("Digite a idade do aluno: "))
                aluno = Aluno(nome, idade)
                self.cadastro_alunos.cadastrar_aluno(aluno)
                print("Aluno cadastrado no sistema com sucesso.")
            else:
                print("Senha de administrador incorreta.")
        elif escolha == '3':
            senha = input("Digite a senha de administrador para advertir aluno da instituição: ")
            if self.administrador.validar_senha(senha):
                nome_aluno = input("Digite o nome do aluno que levará advertência: ")
                self.cadastro_alunos.advertir_aluno(nome_aluno)
            else:
                print("Senha de administrador incorreta.")
        elif escolha == '4':
            senha = input("Digite a senha de administrador para expulsar aluno da instituição: ")
            if self.administrador.validar_senha(senha):
                nome_aluno = input("Digite o nome do aluno a ser expulso: ")
                self.cadastro_alunos.expulsar_aluno(nome_aluno)
            else:
                print("Senha de administrador incorreta!")
        elif escolha == '5':
            print("Tenha um bom dia.")
            return False
        else:
            print("Opção inválida.")
        return True

acoes_aluno = AcoesAluno()
while True:
    continuar = acoes_aluno.realizar_acao()
    if not continuar:
        break
